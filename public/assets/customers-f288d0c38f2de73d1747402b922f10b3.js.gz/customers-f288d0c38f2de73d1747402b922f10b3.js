(function() {
  jQuery(function() {
    return $('#customers').dataTable();
  });

}).call(this);
