(function() {
  jQuery(function() {
    return $('#npi_statuses').dataTable();
  });

}).call(this);
