(function() {
  jQuery(function() {
    return $('#contacts').dataTable();
  });

}).call(this);
