(function() {
  jQuery(function() {
    return $('#comments').dataTable();
  });

}).call(this);
