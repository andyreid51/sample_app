(function() {
  jQuery(function() {
    return $('#carriers').dataTable();
  });

}).call(this);
