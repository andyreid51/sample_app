(function() {
  jQuery(function() {
    return $('#users').dataTable();
  });

}).call(this);
